﻿using Microsoft.Maui.Controls;

namespace fall_detection_2._0
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            // Envolva o MainPage com NavigationPage para permitir navegação
            MainPage = new NavigationPage(new MainPage());
        }
    }
}
