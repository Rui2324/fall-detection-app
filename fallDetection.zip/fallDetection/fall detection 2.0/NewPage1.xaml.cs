using System;
using Microsoft.Maui.Controls;

namespace fall_detection_2._0
{
    public partial class FallAlertPage : ContentPage
    {
        private int countdown = 15; 

        public FallAlertPage()
        {
            InitializeComponent();
            StartCountdown(); 
        }

        private async void StartCountdown()
        {
            while (countdown > 0)
            {
                await Task.Delay(1000); 
                countdown--;
                UpdateCountdownLabel();
            }

            
            if (countdown == 0)
            {
                await SendEmergencyMessage();
            }
        }

        private void UpdateCountdownLabel()
        {
            
            Device.BeginInvokeOnMainThread(() =>
            {
                (FindByName("CountdownLabel") as Label).Text = $"{countdown} s";
            });
        }

        private async Task SendEmergencyMessage()
        {
            //mensagem
            await DisplayAlert("Alerta", "Mensagem de socorro enviada para o contacto predefinido!", "OK");
            //fechar pagina apos alerta
            await Navigation.PopAsync();
        }

        private async void OnConfirmAliveClicked(object sender, EventArgs e)
        {
            // confirma��o do user 
            await DisplayAlert("Al�vio", "Estamos felizes que estejas bem!", "OK");
            // Fecha a p�gina
            await Navigation.PopAsync();
        }
    }
}
