﻿using System;
using Microsoft.Maui.Controls; 
using Microsoft.Maui.Devices.Sensors; 
using System.Numerics; 

namespace fall_detection_2._0
{
    public partial class MainPage : ContentPage
    {
        private Vector3? lastAcceleration = null; 
        private bool isFallDetectionEnabled = false;

        public MainPage()
        {
            InitializeComponent(); 
        }

        private void OnToggleFallDetection(object sender, EventArgs e)
        {
            // estado da queda
            isFallDetectionEnabled = !isFallDetectionEnabled;

            if (isFallDetectionEnabled)
            {
                if (Accelerometer.IsSupported)
                {
                    // Acelometro on
                    Accelerometer.ReadingChanged += OnAccelerometerReadingChanged;
                    Accelerometer.Start(SensorSpeed.UI);
                    statusLabel.Text = "Status: Ativado";
                    DisplayAlert("Fall Detection", "Deteção de quedas ativada!", "OK");
                }
                else
                {
                    // acelometro op
                    DisplayAlert("Erro", "O acelerômetro não é suportado neste dispositivo.", "OK");
                    isFallDetectionEnabled = false;
                }
            }
            else
            {
                // acelometro op2
                Accelerometer.ReadingChanged -= OnAccelerometerReadingChanged;
                Accelerometer.Stop();
                statusLabel.Text = "Status: Desativado";
                DisplayAlert("Fall Detection", "Deteção de quedas desativada!", "OK");
            }
        }

        private async void OnAccelerometerReadingChanged(object sender, AccelerometerChangedEventArgs e)
        {
            // Lê os dados do acelerômetro
            var acceleration = e.Reading.Acceleration;

            // magnitude
            double magnitude = Math.Sqrt(acceleration.X * acceleration.X +
                                         acceleration.Y * acceleration.Y +
                                         acceleration.Z * acceleration.Z);

            // magnitude baixa
            if (magnitude < 0.5 && lastAcceleration.HasValue &&
                Math.Abs(magnitude - lastAcceleration.Value.Length()) > 1.5)
            {
                //para acelometro
                Accelerometer.ReadingChanged -= OnAccelerometerReadingChanged;
                Accelerometer.Stop();

                // alert
                await DisplayAlert("Alerta de Queda", "Queda detectada!", "OK");

                // pagina alert
                await Navigation.PushAsync(new FallAlertPage());
            }

            // dados acelometro
            lastAcceleration = acceleration;
        }
    }
}
